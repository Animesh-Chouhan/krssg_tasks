#include "ros/ros.h"
#include <fstream>
#include <string>
#include <vector>
#include <geometry_msgs/Point.h>
#include <math.h>
#include "ros/package.h"
using namespace std;

int main(int argc,char **argv)
{
     int flag=1;
     ros::init(argc,argv,"publisher_3");
     ros::NodeHandle nh;
     ros::Publisher pub=nh.advertise<geometry_msgs::Point>("Point",2000,true);
     ros::Rate loop_rate(1);
     string s1=ros::package::getPath("krssg_task3");
     s1+="/src/file.txt";
     fstream f(s1.c_str(),ios::in);
     int i,j,maxx=0,maxy=0,curx,cury;
     vector<string> v;
     string s;


     while(f>>s)
     {
        v.push_back(s);
        maxy=s.length();
        maxx++;
     }
     i=0;j=0;
     vector<vector<int> > visited;
     visited.resize(maxx);
     vector<vector<long double> > dist;
     dist.resize(maxx);
     vector<vector<long long> > parent;
     parent.resize(maxx);
     vector<vector<long long> > original;
     original.resize(maxx);

     long double mini;
     long long temp;
    // long parent[maxx][maxy];
     for(i=0;i<maxx;i++)
     {
         visited[i].resize(maxy);
         dist[i].resize(maxy);
         parent[i].resize(maxy);
         original[i].resize(maxy);
         for(j=0;j<maxy;j++)
         {
              dist[i][j]=maxx*maxy;
              visited[i][j]=0;
         }
     }
     cout<<maxx<<" "<<maxy<<"\n";
     dist[maxx-1][maxy-1]=0;
     do
     {
        mini=maxx*maxy;
        for(i=0;i<maxx;i++)
        {
            for(j=0;j<maxy;j++)
            {
                if(visited[i][j]==0&&dist[i][j]<mini&&v[i][j]!='1')
                {
                    curx=i;
                    cury=j;
                    mini=dist[i][j];
                }
            }
        }
        visited[curx][cury]=1;
        for(int k=-1;k<2;k++)
        {
            for(int l=-1;l<2;l++)
            {
                if(curx+k>=0&&curx+k<maxx&&cury+l>=0&&cury+l<maxy)
                {
                    if(dist[curx+k][cury+l]>dist[curx][cury]+sqrt(abs(k)+abs(l)))
                    {
                        dist[curx+k][cury+l]=dist[curx][cury]+sqrt(abs(k)+abs(l));
                        parent[curx+k][cury+l]=1000*curx+cury;
                    }
                }
            }
        }
     }
     while(curx!=0||cury!=0);

     geometry_msgs::Point p;

    do
    {
        if(flag==1)
        {
            p.x=maxx;
     p.y=maxy;
     pub.publish(p);
     ros::spinOnce();
     loop_rate.sleep();
     flag=0;
        }
        else
        {
        p.x=curx;
        p.y=cury;
        pub.publish(p);
        ros::spinOnce();
       loop_rate.sleep();
   //     ROS_INFO("%d,%d",p.x,p.y);
        cout<<curx<<","<<cury<<"\n";
        temp=parent[curx][cury];
        curx=temp/1000;
        cury=temp%1000;
        }
    }
    while(curx!=maxx-1||cury!=maxy-1);
    p.x=curx;
    p.y=cury;
    pub.publish(p);
  /*   while(f>>num)
     {
        ROS_INFO("Read : %d",num);
      //  v.data.push_back(num);
     }

    // pub.publish(v);
     //ros::Duration(1).sleep();
*/
     //ros::spin();
      ros::spinOnce();
       loop_rate.sleep();
     return 0;
}
