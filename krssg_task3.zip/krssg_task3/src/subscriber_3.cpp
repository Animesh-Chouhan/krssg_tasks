#include <iostream>
#include "ros/ros.h"
#include "geometry_msgs/Point.h"
#include "geometry_msgs/Twist.h"
#include "turtlesim/SetPen.h"
#define PI 3.14159
using namespace std;
int curx=0,cury=0,flag=1;
double sfx,sfy,curang=0,temp=0;
ros::Publisher pub1;
void turtle_move(const geometry_msgs::Point& p)
{
   geometry_msgs::Twist vel_msg;
   ros::Rate loop_rate(1);
   //cout<<p.x<<" "<<p.y<<" ";
   if(flag==1||flag==2)
   {
        if(flag!=2)
        {
        sfx=5.544445*2.0/p.y;
        sfy=5.544445*2.0/p.x;
        ros::NodeHandle srv;
        ros::ServiceClient client = srv.serviceClient<turtlesim::SetPen>("turtle1/set_pen");
        turtlesim::SetPen sr;
        sr.request.off=1;
        if(!client.call(sr))
        {
            cout<<"Error";
        }
        else
        {
        vel_msg.linear.x=0;
        vel_msg.linear.y=0;
        vel_msg.linear.z=0;
        vel_msg.angular.x=0;
        vel_msg.angular.y=0;
        vel_msg.angular.z=3.0*PI/4.0;
        pub1.publish(vel_msg);
        loop_rate.sleep();
        vel_msg.angular.z=0;
        vel_msg.linear.x=5.5*sqrt(2);
        pub1.publish(vel_msg);
        loop_rate.sleep();
        vel_msg.linear.x=0;
        vel_msg.angular.z=-3.0*PI/4.0;

        pub1.publish(vel_msg);
        loop_rate.sleep();
         sr.request.off=0;
        if(!client.call(sr))
        {
            cout<<"Error";
        }
        }
        }
        cout<<sfx<<" "<<sfy<<"\n";
        if(flag==2)
        {
            //GoToOrigin
        }
        flag++;
   }
   else if(p.x!=0&&p.y!=0)
   {

        int x=p.y,y=-p.x;
        y=y-cury;
        x=x-curx;
        cury=-p.x;
        curx=p.y;
        temp=atan((double)sfy*y/(x*sfx));
        if(x<0)
        {
            if(y<0)
            {
                temp=PI+temp;
            }
            else if(y!=0)
            {
                temp=PI-temp;
            }
            else
            {
                temp=PI;
            }
        }
        vel_msg.linear.x=0;
        vel_msg.linear.y=0;
        vel_msg.linear.z=0;
        vel_msg.angular.x=0;
        vel_msg.angular.y=0;
        vel_msg.angular.z=temp-curang;
        pub1.publish(vel_msg);
        loop_rate.sleep();
        if(y!=0&&x!=0)
        vel_msg.linear.x=sqrt(sfx*sfx+sfy*sfy);
        else if(y==0)
        vel_msg.linear.x=sfx;
        else
        vel_msg.linear.x=sfy;
        cout<<"x :"<<vel_msg.linear.x<<" w :"<<vel_msg.angular.z<<"\n";

        vel_msg.angular.z=0;
        curang=temp;
        pub1.publish(vel_msg);
       // ros::spinOnce();
        loop_rate.sleep();

   }
}

int main(int argc,char **argv)
{
    ros::init(argc,argv,"subscriber_3");
    ros::NodeHandle nh,nh2;
    ros::Subscriber sub=nh.subscribe("Point",1000,turtle_move);
    ros::NodeHandle nh1;
   // ros::Rate loop_rate(1);
    pub1=nh1.advertise<geometry_msgs::Twist>("turtle1/cmd_vel",1000,true);
    ros::spin();
    //sub.shutdown();
    //sub=nh.subscribe("Topic_2",1000,val_store);
    //ros::loop_rate.sleep();
    return 0;
}
