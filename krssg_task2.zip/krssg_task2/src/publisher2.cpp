#include "ros/ros.h"
#include <fstream>
#include <std_msgs/Int32MultiArray.h>
#include "ros/package.h"
using namespace std;

int main(int argc,char **argv)
{
     ros::init(argc,argv,"publisher2");
     ros::NodeHandle nh;
     ros::Publisher pub=nh.advertise<std_msgs::Int32MultiArray>("Topic_2",1000,true);
     ros::Rate loop_rate(1);
     string s=ros::package::getPath("krssg_task2");
     s+="/src/file2.txt";
     fstream f(s.c_str(),ios::in);
     std_msgs::Int32MultiArray v1;
     int num;
     while(f>>num)
     {
        ROS_INFO("Read : %d",num);
        v1.data.push_back(num);

     }
     pub.publish(v1);
     ros::spin();

     return 0;
}
