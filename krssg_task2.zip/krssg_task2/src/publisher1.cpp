#include "ros/ros.h"
#include <fstream>
#include <std_msgs/Int32MultiArray.h>
#include "ros/package.h"
using namespace std;

int main(int argc,char **argv)
{
     ros::init(argc,argv,"publisher1");
     ros::NodeHandle nh;
     ros::Publisher pub=nh.advertise<std_msgs::Int32MultiArray>("Topic_1",2000,true);
     ros::Rate loop_rate(1);
     string s=ros::package::getPath("krssg_task2");
     s+="/src/file1.txt";
     fstream f(s.c_str(),ios::in);
     std_msgs::Int32MultiArray v;
     int num;
     while(f>>num)
     {
        ROS_INFO("Read : %d",num);
        v.data.push_back(num);
     }

     pub.publish(v);
     //ros::Duration(1).sleep();
     ros::spin();

     return 0;
}
