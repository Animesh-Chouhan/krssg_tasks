#include <iostream>
#include "ros/ros.h"
#include "ros/package.h"
#include <fstream>
#include <algorithm>
#include <string>
#include <std_msgs/Int32MultiArray.h>

using namespace std;
std_msgs::Int32MultiArray Vec;
int flag=0;

void val_store1(const std_msgs::Int32MultiArray& v1)
{
    vector<int>::const_iterator itr = v1.data.begin();
   for(;itr!=v1.data.end();itr++)
   {
  //  cout<<v1.data[i];
    Vec.data.push_back(*itr);
   }
   //cout<<"printed";
    flag++;
   ROS_INFO("DATA RECEIVED ON TOPIC_1, number of elments : %d\n",v1.data.size());
}

void val_store2(const std_msgs::Int32MultiArray& v2)
{
    vector<int>::const_iterator itr1 = v2.data.begin();
   for(;itr1!=v2.data.end();itr1++)
   {
   // cout<<v2.data[i];
    Vec.data.push_back(*itr1);
   }
   //cout<<"printed";

   ROS_INFO("DATA RECEIVED ON TOPIC_2, number of elments : %d\n",v2.data.size());
   flag++;
}

int main(int argc,char **argv)
{
    ros::init(argc,argv,"subscriber1");
    ros::NodeHandle nh1,nh2;
    ros::Subscriber sub1=nh1.subscribe("Topic_1",1000,val_store1);
    ros::Subscriber sub2=nh2.subscribe("Topic_2",1000,val_store2);


    while(flag!=2)
    {
        ros::spinOnce();
    }
    sort(Vec.data.begin(),Vec.data.end());
    string path=ros::package::getPath("krssg_task2");
    path+="/src/sorted.txt";
    fstream f(path.c_str(),ios::out);
    vector<int>::const_iterator itr2 = Vec.data.begin();
    for(;itr2!=Vec.data.end();itr2++)
    {

        f<<*itr2<<" ";
    }
    ROS_INFO("Elements sorted and written to file sorted.txt\n");

    //sub.shutdown();
    //sub=nh.subscribe("Topic_2",1000,val_store);
    //ros::loop_rate.sleep();
    return 0;
}
