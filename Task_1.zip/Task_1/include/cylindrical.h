#ifndef CYLINDRICAL_H
#define CYLINDRICAL_H
#include "vector1.h"

class cylindrical:public system<cylindrical>
{
    public:
        double rad_dis,azi,height;
        cylindrical();
        ~cylindrical();
        cylindrical operator+(cylindrical);
        cylindrical(double,double,double);
        cylindrical operator-(cylindrical);
        cylindrical operator*(double);
        cylindrical origin_chng(cylindrical);
        vector1 convert();
        cylindrical convert(vector1);
        void input();
        void disp();

    protected:
    private:
};

#endif // CYLINDRICAL_H
