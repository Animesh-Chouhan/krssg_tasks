#include"system.h"
#ifndef VECTOR1_H
#define VECTOR1_H

class vector1 :public system<vector1>
{
	public :
        double x,y,z;
        vector1();
        vector1(double,double,double);
        vector1 operator+(vector1);
        vector1 operator-(vector1);
        vector1 operator*(double);
        vector1 origin(vector1,vector1);
        //virtual v convert(int);
        ~vector1();
        void input();
        void disp();
        //spherical convert(int);
        //v convert(int){};

};

#endif
