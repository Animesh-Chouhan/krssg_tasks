#ifndef RUN_H
#define RUN_H

#include "vector1.h"
#include "spherical.h"
#include "cylindrical.h"
#include "complex1.h"
#include  <iostream>
using namespace std;

class Run
{
    public:
        Run();
        ~Run();
        void main_menu();
        void perform();
        void history();
        void add();
        void subtract();
        void convert(int,vector1);
        void origin();
        void scale();
        void multiply();
        void divide();
        void mod();
        vector1 inp(int);
        void display(vector1);
        void ins();
    protected:
    private:
};

#endif // RUN_H
