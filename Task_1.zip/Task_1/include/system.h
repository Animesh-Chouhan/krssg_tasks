#ifndef SYSTEM_H
#define SYSTEM_H
//#include "vector1.h"

template <class t>
class system
{
	public :

	system();
    ~system();
	virtual t operator+(t){};
	virtual t operator-(t){};
	virtual t operator*(double){};
	virtual t origin_chng(t){};
	virtual t convert(int){};
	virtual void disp(){};
	virtual void input(){};
//	virtual vector1 convert(){};
	//virtual t convert(u,int){};
};

#endif
