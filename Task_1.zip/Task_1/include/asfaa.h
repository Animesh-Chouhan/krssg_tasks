#ifndef ASFAA_H
#define ASFAA_H

#include <complex>


class asfaa
{
    public:
        asfaa();
        ~asfaa();
    protected:
    private:
};

#endif // ASFAA_H
