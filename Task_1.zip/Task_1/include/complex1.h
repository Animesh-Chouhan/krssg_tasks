#ifndef COMPLEX1_H
#define COMPLEX1_H
#include "vector1.h"

class complex1:public system<complex1>
{
    public:
        double x,y;
        complex1();
        ~complex1();
         complex1(double,double);
        complex1 operator+(complex1);
        complex1 operator-(complex1);
        complex1 operator*(double);
        complex1 operator*(complex1);
        complex1 operator/(complex1);
        void input();
        void disp();
        void multiply();
        void divide();
        double arg();
        double real();
        double img();
        void sqroot();
        double mod();
        complex1 conj();
        //complex1 origin(complex1,complex1);
        //vector1 convert();
        //complex1 convert(vector1);
    protected:
    private:
};

#endif // COMPLEX1_H
