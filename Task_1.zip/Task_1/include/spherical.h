#ifndef SPHERICAL_H
#define SPHERICAL_H
#include "vector1.h"

class spherical:public system<spherical>
{
    public:
        double r,azi,pol;
        spherical();
        ~spherical();
        spherical(double,double,double);
        spherical operator+(spherical);
        spherical operator-(spherical);
        spherical operator*(double);
        spherical origin(spherical,spherical);
        vector1 convert();
        spherical convert(vector1);
        void input();
        void disp();
       // spherical convert();
    protected:
    private:
};

#endif // SPHERICAL_H
