#include "spherical.h"
#include <math.h>
#include <iostream>
using namespace std;
spherical::spherical()
{
    //ctor
}

spherical::spherical(double a,double b,double c)
{
    //ctor
    r=a;
    azi=b;
    pol=c;
}

spherical::~spherical()
{
    //dtor
}

spherical spherical::operator*(double f)
{
    spherical s;
    s=this->convert(this->convert()*f);
    return s;
}

spherical spherical::operator+(spherical ob)
{
    vector1 v=(this->convert()+ob.convert());
    return (this->convert(v));
}

spherical spherical::operator-(spherical ob)
{
    vector1 v=(this->convert()-ob.convert());
    return (this->convert(v));
}

vector1 spherical::convert()
{
    vector1 ob;
    ob.z=r*cos(pol);
    ob.x=r*sin(pol)*cos(azi);
    ob.y=r*sin(azi)*sin(pol);
    return ob;
}

spherical spherical::convert(vector1 v)
{
    spherical s;
    s.r=sqrt(v.x*v.x+v.y*v.y+v.z*v.z);
    s.azi=atan(v.y/v.x);
    s.pol=atan((sqrt(v.x*v.x+v.y*v.y))/v.z);
    return s;
}

void spherical::input()
{
    cout<<"Enter radial co-ordinate : ";
    cin>>r;
    cout<<"Enter azimuthal co-ordinate : ";
    cin>>azi;
    cout<<"Enter polar co-ordinate : ";
    cin>>pol;
}

void spherical::disp()
{
    cout<<"Radial co-ordinate : "<<r<<"\nAzimuthal co-ordinate : "<<azi<<"\nPolar co-ordinate : "<<pol<<"\n";
}
