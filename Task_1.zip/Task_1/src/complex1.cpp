#include "complex1.h"
#include <iostream>
#include <math.h>
#define PI 3.14159
using namespace std;
complex1::complex1()
{
    //ctor
}

complex1::~complex1()
{
    //dtor
}

complex1::complex1(double a,double b)
{
    //ctor
    x=a;
    y=b;
}

complex1 complex1::operator+(complex1 c)
{
    complex1 c1;
    c1.x=c.x+x;
    c1.y=c.y+y;
    return c1;
}

complex1 complex1::operator-(complex1 c)
{
    complex1 c1;
    c1.x=x-c.x;
    c1.y=y-c.y;
    return c1;
}

complex1 complex1::operator*(double f)
{
    complex1 c;
    c.x=x*f;
    c.y=y*f;
    return c;
}

complex1 complex1::conj()
{
    complex1 c1;
    c1.x=x;
    c1.y=-y;
    return c1;
}

double complex1::mod()
{
    return (sqrt(x*x+y*y));
}

complex1 complex1::operator*(complex1 c)
{
    complex1 c1;
    c1.x=x*c.x-y*c.y;
    c1.y=y*c.x+x*c.y;
    return c1;
}

complex1 complex1::operator/(complex1 c)
{
    complex1 c1;
    c1=(*this)*(c.conj());
    c1.x=c1.x/(c.mod()*c.mod());
    c1.y=c1.y/(c.mod()*c.mod());
    return c1;
}

void complex1::input()
{
    cout<<"Enter real part : ";
    cin>>x;
    cout<<"Enter imaginary part : ";
    cin>>y;
}

double complex1::arg()
{
    double ang=atan(y/x);
    if(x<0)
    {
        if(y>0)
        ang=ang+PI;
        else if(y<0)
        ang=-PI+ang;
    }
    return (ang);
}
void complex1::disp()
{
    if(y>=0)
    cout<<x<<"+"<<y<<"i\n";
    else
    cout<<x<<y<<"i\n";
}
