#include "Run.h"
#include <math.h>

Run::Run()
{
    //ctor
}

Run::~Run()
{
    //dtor
}

vector1 Run::inp(int ch)
{
     int flag=1;
     do
    {
        switch(ch)
        {
        case 2: {
                    cylindrical c;
                    c.input();
                    flag=1;
                    return (c.convert());
                }
        case 3: {
                    spherical s;
                    s.input();
                    flag=1;
                    return (s.convert());
                }
        case 4: {
                    vector1 v;
                    v.input();
                    flag=1;
                    return v;
                }
        default: cout<<"Invalid choice, try again.\nEnter the system for co-ordinate input : ";
                 cin>>ch;
                 flag=0;
        }
    }
    while((!(ch>1&&ch<5))||flag!=1);
}
void Run::display(vector1 v)
{
    int ch;
    do
    {
        cout<<"Enter the system for the result : ";
        cin>>ch;
        switch(ch)
        {
        case 2: {
                cylindrical cy;
                cy=cy.convert(v);
                cy.disp();
                return;
                }
        case 3: {
                spherical s;
                s=s.convert(v);
                s.disp();
                return;
                }
        case 4: {
                v.disp();
                return;
                }
        }
        cout<< "Invalid choice of system, try again.\n";
    }
    while(1);
}
void Run::add()
{
    int ch1,ch2;
    int flag=0;
    cout<<"Enter the system of first co-ordinate : ";
    cin>>ch1;
    cout<<"Enter the system of second co-ordinate : ";
    cin>>ch2;
    if((ch1==1&&ch2!=1)||((ch1!=1)&&(ch2==1)))
    {
        cout<<"Addition not possible of complex number with numbers of other system.\n";
    }
    else if(ch1==1&&ch2==1)
    {
        int ch=1;
        complex1 c1,c2;
        cout<<"1st complex number\n";
        c1.input();
        cout<<"2nd complex number\n";
        do
        {
        switch(ch)
        {
            case 1:

                    c2.input();
                    c1=c1+c2;
                    c1.disp();
                    cout<<"1. To add more complex numbers \n2. Go back to previous menu\nEnter your choice : ";
                    cin>>ch;
                    break;
            case 2:
                    break;
            default : cout<<"Invalid choice, try again.\n";
        }
        }
        while(ch!=2);
    }
    else if(ch1>1&&ch1<5&&ch1>1&&ch2<5)
    {
        int ch=1;
        vector1 v1,v2;
        v1=inp(ch1);
        do
        {
            switch(ch)
            {
            case 1:
                    if(flag==0)
                    {
                     flag=1;
                    }
                    else
                    {
                        cout<<"Enter the system of co-ordinate to be added : ";
                        cin>>ch2;
                    }
                    v2=inp(ch2);
                    v1=v1+v2;
                    display(v1);
                    cout<<"1. To add more numbers to the result\n2. Go back to previous menu\nEnter your choice : ";
                    cin>>ch;
                    break;
            case 2:
                    break;
            default :
                    cout<<"Invalid choice, try again.\n";
            }
        }
        while(ch!=2);
    }
    else
    {
        cout<<"One of the system you have entered is invalid, try again.\n";
    }
}

void Run::subtract()
{
    int ch1,ch2;
    int flag=0;
    cout<<"Enter the system of first co-ordinate : ";
    cin>>ch1;
    cout<<"Enter the system of second co-ordinate : ";
    cin>>ch2;
    if((ch1==1&&ch2!=1)||((ch1!=1)&&(ch2==1)))
    {
        cout<<"Subtraction not possible of complex number with numbers of other system.\n";
    }
    else if(ch1==1&&ch2==1)
    {
        int ch=1;
        complex1 c1,c2;
        cout<<"1st complex number\n";
        c1.input();
        cout<<"2nd complex number\n";
        do
        {
        switch(ch)
        {
            case 1:
                    c2.input();
                    c1=c1-c2;
                    c1.disp();
                    cout<<"1. To subtract more complex numbers \n2. Go back to previous menu\nEnter your choice : ";
                    cin>>ch;
                    break;
            case 2:
                    break;
            default : cout<<"Invalid choice, try again.\n";
        }
        }
        while(ch!=2);
    }
    else if(ch1>1&&ch1<5&&ch1>1&&ch2<5)
    {
        int ch=1;
        vector1 v1,v2;
        v1=inp(ch1);
        do
        {
            switch(ch)
            {
            case 1:
                    if(flag==0)
                    {
                        flag=1;
                    }
                    else
                    {
                        cout<<"Enter the system of co-ordinate to be subtracted : ";
                        cin>>ch2;
                    }
                    v2=inp(ch2);
                    v1=v1-v2;
                    display(v1);
                    cout<<"1. To subtract more numbers from the result\n2. Go back to previous menu\nEnter your choice : ";
                    cin>>ch;
                    break;
            case 2:
                    break;
            default :
                    cout<<"Invalid choice, try again.\n";
            }
        }
        while(ch!=2);
    }
    else
    {
        cout<<"One of the system you have entered is invalid, try again.\n";
    }
}

void Run::origin()
{
    int ch1,ch2;
    cout<<"Enter the system of the co-ordinate : ";
    cin>>ch1;
    cout<<"Enter the system of the new origin : ";
    cin>>ch2;
    if((ch1==1&&ch2!=1)||((ch1!=1)&&(ch2==1)))
    {
        cout<<"Origin shift not possible of complex number with numbers of other system.\n";
    }
    else if(ch1==1&&ch2==1)
    {
        complex1 c1,c2,c;
        cout<<"Enter complex number\n";
        c1.input();
        cout<<"Enter new origin\n";
        c2.input();
        c=c1-c2;
        c.disp();
    }
    else if(ch1>1&&ch1<5&&ch1>1&&ch2<5)
    {
        int ch;
        vector1 v1,v2,v;
        v1=inp(ch1);
        v2=inp(ch2);
        v=v1-v2;
        display(v);
    }
    else
    {
        cout<<"One of the system you have entered is invalid, try again.\n";
    }
}

void Run::scale()
{
    vector1 v1;
    int ch;
    char cr='y';
    double f;
    cout<<"Enter choice of system : ";
    cin>>ch;
    if(ch!=1)
    {
        v1=inp(ch);
        do
        {
            switch(cr)
            {
            case 'Y':
            case 'y':
            cout<<"Enter scale factor : ";
            cin>>f;
            v1=v1*f;
            display(v1);
            cout<<"Do you want to scale the same no. again?<Y/N> : ";
            cin>>cr;
            break;
            case 'n':
            case 'N':
            break;
            default : cout<<"Invalid choice, try again.\nDo you want to scale the same no. again?<Y/N> : ";
            cin>>cr;
            }
        }
        while(cr!='n'&&cr!='N');
    }
    else if(ch==1)
    {
        complex1 c;
        c.input();
        do
        {
            switch(cr)
            {
            case 'Y':
            case 'y':
            cout<<"Enter scale factor : ";
            cin>>f;
            c=c*f;
            c.disp();
            cout<<"Do you want to scale the same no. again?<Y/N> : ";
            cin>>cr;
            break;
            case 'n':
            case 'N':
            break;
            default : cout<<"Invalid choice, try again.\nDo you want to scale the same no. again?<Y/N> : ";
            cin>>cr;
            }
        }
        while(cr!='n'&&cr!='N');
    }
}

void Run::multiply()
{
    complex1 c1,c2;
    char cr='y';
    cout<<"Enter first complex number : \n";
    c1.input();
    do
    {
        switch(cr)
        {
        case 'Y':
        case 'y':
                cout<<"Enter complex number to be multiplied with : \n";
                c2.input();
                c1=c1*c2;
                c1.disp();
                cout<<"Do you wish to you multiply another no. with the result?<Y/N> : ";
                cin>>cr;
                break;
        case 'n':
        case 'N':
                break;
        default : cout<<"Invalid choice, try again.\nDo you wish to you multiply another no. with the result?<Y/N> : ";
                  cin>>cr;
        }
    }
        while(cr!='n'&&cr!='N');
}

void Run::divide()
{
     complex1 c1,c2;
    char cr='y';
    cout<<"Enter first complex number : \n";
    c1.input();
    do
    {
        switch(cr)
        {
        case 'Y':
        case 'y':
                cout<<"Enter complex number to be divided with : \n";
                c2.input();
                c1=c1/c2;
                c1.disp();
                cout<<"Do you wish to use another no. to divide the result?<Y/N> : ";
                cin>>cr;
                break;
        case 'n':
        case 'N':
                break;
        default : cout<<"Invalid choice, try again.\nDo you wish to use another no. to divide the result?<Y/N> : ";
                  cin>>cr;
        }
    }
        while(cr!='n'&&cr!='N');
}

void Run::convert(int c,vector1 v)
{
    int ch;
    if(c==1)
    {
        cout<<"Enter the system of original co-ordinates : ";
        cin>>ch;
        v=inp(ch);
    }
    display(v);

}
void Run::perform()
{
    enum p_menu{ad,sub,conv,orig,scal,multi,div,arg,real,img,mod,conj,Exit};
    int ch;
     do
    {
        cout<<"--To perform an operation--\n1  : Add\n2  : Subtract\n3  : Convert\n4  : Origin shift\n5  : Scale up/down\n6  : Multiply(C)\n7  : Divide(C)\n8  : Argument(C)\n9  : Real part(C)\n10 : Imaginary part(C)\n11 : Modulus(C)\n12 : Conjugate(C)\n13 : Back to previous menu\nNote : (C)-defined only for complex numbers\nEnter your choice : ";
        cin>>ch;
        p_menu m=p_menu(ch-1);
        switch(m)
        {
            case ad : add();
                      break;
            case sub : subtract();
                       break;
            case conv :   {
                           vector1 v;
                           convert(1,v);
                           break;
                          }
            case orig : origin();
                        break;
            break;
            case scal: scale();
                       break;
            case multi : multiply();
                            break;
            case div : divide();
                          break;
            case arg : {
                        complex1 c;
                        c.input();
                        cout<<"Argument : "<<c.arg()<<"\n";
                        break;
                       }
            case real :
            break;
            case img :
            break;
            case mod :  {
                        complex1 c;
                        c.input();
                        cout<<"Modulus : "<<c.mod()<<"\n";
                        break;
                        }
            case conj : {
                         complex1 c,c1;
                         c.input();
                         c1=c.conj();
                         cout<<"Conjugate : ";
                         c1.disp();
                         break;
                         }
            case Exit :
            break;
            default : cout<<"Invalid choice, try again.\n";
            break;
        }
    }
    while(ch!=13);
}

void Run::history()
{

}

void Run::ins()
{
    cout<<"For the convenience of the user and the programmer the systems have been arranged in alphabetical order.\nWhenever the type of system is asked enter \n1 for complex\n2 for cylindrical\n3 for spherica\n4 for vector\nNote : All the angles are in radians and have been taken from the +ve direction of axes.\n";
    return;
}

void Run::main_menu()
{
    enum menu{perf,hist,inst,Exit};
    int ch;
    do
    {
        cout<<"--Main Menu--\n1 : Perform an operation\n2 : History of operations\n3 : Instructions\n4 : Exit\nEnter your choice : ";
        cin>>ch;
        menu m=menu(ch-1);
        switch(m)
        {
            case perf : perform();
                        break;
            case hist : history();
                        break;
            case inst  : ins();
                         break;
            case Exit : cout<<"\n--Thanks for using the program.--\n";
                        break;
            default   : cout<<"\nInvalid choice, try again.\n";
        }
    }
    while(ch!=4);
}
