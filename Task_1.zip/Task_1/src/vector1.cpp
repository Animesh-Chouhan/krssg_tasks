#include"vector1.h"
#include <iostream>
using namespace std;
vector1 vector1::operator+(vector1 ob)
{
    vector1 obj;
    obj.x=x+ob.x;
    obj.y=y+ob.y;
    obj.z=z+ob.z;
    return obj;
}

vector1 vector1::operator-(vector1 ob)
{
    vector1 obj;
    obj.x=x-ob.x;
    obj.y=y-ob.y;
    obj.z=z-ob.z;
    return obj;
}

vector1 vector1::operator*(double f)
{

    x=x*f;
    y=y*f;
    z=z*f;
    return *this;
}

vector1 vector1::origin(vector1 old,vector1 orig)
{
    return (old-orig);
}

vector1::vector1()
{
    x=0.0;
    y=0.0;
    z=0.0;
}

vector1::~vector1()
{

}


vector1::vector1(double a,double b ,double c)
{
    x=a;
    y=b;
    z=c;
}
void vector1::input()
{
    cout<<"Enter x :";
    cin>>x;
    cout<<"Enter y :";
    cin>>y;
    cout<<"Enter z :";
    cin>>z;
}

void vector1::disp()
{
    cout<<"x : "<<x<<"\ny : "<<y<<"\nz : "<<z<<"\n";
}
