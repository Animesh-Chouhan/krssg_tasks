#include"system.h"
#include"vector1.h"
#include "spherical.h"
#include "complex1.h"
#include "cylindrical.h"

template <class t>
system<t>::system()
{

}

template <class t>
system<t>::~system()
{

}

template class system<vector1>;
template class system<cylindrical>;
template class system<spherical>;
template class system<complex1>;
