#include "cylindrical.h"
#include <math.h>
#include <iostream>
using namespace std;
cylindrical::cylindrical(double a,double b,double c)
{
    rad_dis=a;
    azi=b;
    height=c;
}

cylindrical::cylindrical()
{

}

cylindrical::~cylindrical()
{

}

cylindrical cylindrical::operator+(cylindrical c)
{
    cylindrical c1;
    c1=this->convert(this->convert()+c.convert());
    return c1;
}

cylindrical cylindrical::operator-(cylindrical c)
{
    cylindrical c1;
    c1=this->convert(this->convert()-c.convert());
    return c1;
}

cylindrical cylindrical::operator*(double f)
{

    return this->convert((this->convert()*f));
}

cylindrical cylindrical::origin_chng(cylindrical c)
{
    *this=this->operator-(c);
    return *this;
}
vector1 cylindrical::convert()
{
    vector1 v;
    v.x=rad_dis*cos(azi);
    v.y=rad_dis*sin(azi);
    v.z=height;
    return v;
}
cylindrical cylindrical::convert(vector1 v)
{
    cylindrical c;
    c.rad_dis=sqrt(v.x*v.x+v.y*v.y);
    c.azi=atan(v.y/v.x);
    c.height=v.z;
    return c;
}
void cylindrical::input()
{
    cout<<"Enter radial distance : ";
    cin>>rad_dis;
    cout<<"Enter azimuthal co-ordinate : ";
    cin>>azi;
    cout<<"Enter height : ";
    cin>>height;
}

void cylindrical::disp()
{
    cout<<"Radial distance : "<<rad_dis<<"\nAzimuthal co-ordinate : "<<azi<<"\nHeight : "<<height<<"\n";
}
